package com.ril.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ril.model.Customer;
import com.ril.model.Product;
import com.ril.service.CustomerService;
import com.ril.service.ProductService;

@RestController
@RequestMapping("/api/ril")
public class RILCustomerRestController {
	 private static final Logger logger = LogManager.getLogger(RILCustomerRestController.class);

	@Autowired
	private CustomerService customerService;
	@Autowired
	private ProductService productService;

	

	@RequestMapping(value = "/allcustomers")
	public ResponseEntity<List<Customer>> getAllProduct() {
		List<Customer> listOfProduct = customerService.getAllCustomer();
		return new ResponseEntity<List<Customer>>(listOfProduct, HttpStatus.OK);
	}

	@RequestMapping(value = "/customer/{id}")
	public ResponseEntity<Customer> getOneProduct(@PathVariable("id") int id) {
		Customer listOfProduct = customerService.findCustomerById(id);
		return new ResponseEntity<Customer>(listOfProduct, HttpStatus.OK);
	}

	@RequestMapping(value = "/purchaseproduct/{customerid}/{productid}")
	public ResponseEntity<String> purchaseProduct(@PathVariable("customerid") int customer_id,
			@PathVariable("productid") int product_id) {
		logger.info("pruchase product called for "+customer_id +" & Product "+product_id);
		try {
			Product product = productService.findProductById(product_id);
			Customer customer = customerService.findCustomerById(customer_id);
			if (product != null && customer != null) {
				List<Product> allpuchasedProdcutByCustomer = customer.getCartProduct();
				
				int totalCost = 0;
				for(Product allproduct: allpuchasedProdcutByCustomer) {
					totalCost +=allproduct.getPrice();
				}
				if(totalCost>=customer.getPurchase_points()) {
					return new ResponseEntity<String>("Customer product purchase point exceed!", HttpStatus.OK);
				}else {
					customerService.addToCart(customer_id, product);
				
					return new ResponseEntity<String>("Added to cart!", HttpStatus.OK);
				}
			}
			else
				return new ResponseEntity<String>("Invalid Product and Cutomer information!", HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@RequestMapping("/showcart/{customerid}")
	public ResponseEntity<List<Product>> showMyCart(@PathVariable("customerid") int customer_id) {
		List<Product> list = customerService.findCustomerById(customer_id).getCartProduct();
		
		logger.info("show product cart called for "+customer_id );
		if(list!=null)
		return new ResponseEntity<List<Product>>(list,
				HttpStatus.OK);
		else
			return new ResponseEntity<List<Product>>(new ArrayList<>(),
					HttpStatus.OK);
	}

}
