package com.ril.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ril.model.Product;
import com.ril.service.ProductService;

@RestController
@RequestMapping("/api/ril")
public class RILProductRestController {

	@Autowired
	private ProductService productService;
	
	@RequestMapping(value="/allproducts")
	public ResponseEntity<List<Product>> getAllProduct(){
		List<Product> listOfProduct = productService.getAllProduct();
		return new ResponseEntity<List<Product>>(listOfProduct,HttpStatus.OK);
	}
	
	@RequestMapping(value="/product/{id}")
	public ResponseEntity<Product> getOneProduct(@PathVariable("id") int id){
		Product listOfProduct = productService.findProductById(id);
		return new ResponseEntity<Product>(listOfProduct,HttpStatus.OK);
	}
	
	
}
