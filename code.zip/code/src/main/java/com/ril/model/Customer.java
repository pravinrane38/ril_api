package com.ril.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6494693130312197790L;
	@Id
	private int customer_id;
	private String cutomer_name;
	private int purchase_points;
	
	@ManyToMany
	@JoinTable(
		        name = "Employee_Project", 
		        joinColumns = { @JoinColumn(name = "customer_id") }, 
		        inverseJoinColumns = { @JoinColumn(name = "product_id") }
		    )
	private List<Product> cartProduct;
	
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCutomer_name() {
		return cutomer_name;
	}
	public void setCutomer_name(String cutomer_name) {
		this.cutomer_name = cutomer_name;
	}
	public int getPurchase_points() {
		return purchase_points;
	}
	public void setPurchase_points(int purchase_points) {
		this.purchase_points = purchase_points;
	}
	public List<Product> getCartProduct() {
		return cartProduct;
	}
	public void setCartProduct(List<Product> cartProduct) {
		this.cartProduct = cartProduct;
	}
	
	
	
}
