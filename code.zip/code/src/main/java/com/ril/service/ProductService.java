package com.ril.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.model.Product;
import com.ril.repo.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	public List<Product> getAllProduct(){
		List<Product> listOfProduct = productRepository.findAll();
		return listOfProduct;
	}
	
	
	public Product findProductById(int id) {
		return productRepository.getOne(id);
	}
}
