package com.ril.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.model.Customer;
import com.ril.model.Product;
import com.ril.repo.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	public List<Customer> getAllCustomer(){
		return customerRepository.findAll(); 
	}
	
	
	public Customer findCustomerById(int id) {
		return customerRepository.getOne(id);
	}
	
	@Transactional
	public void addToCart(int customer_id,Product product) {
		Customer customer = customerRepository.getOne(customer_id);
		customer.getCartProduct().add(product);
		customerRepository.save(customer);
	}
	
}
