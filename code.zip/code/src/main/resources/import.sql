insert into product(product_id,product_name,price) values(1, 'product1', 100);
insert into product(product_id,product_name,price) values(2, 'product2', 200);

insert into customer(customer_id,cutomer_name,purchase_points) values (3,'pqr',200);
insert into customer(customer_id,cutomer_name,purchase_points) values (1,'abc',1000);
insert into customer(customer_id,cutomer_name,purchase_points) values (2,'xyz',2000);